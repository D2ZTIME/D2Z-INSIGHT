import React from 'react';
import { Play, Volume2 } from 'lucide-react';

const VideoSection: React.FC = () => {
  return (
    <section id="videos" className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Vídeos em Destaque</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Confira nossos vídeos demonstrativos e tutoriais sobre os produtos da D2Z Shop.
            Aprenda como utilizar e aproveitar ao máximo cada item.
          </p>
        </div>

        {/* Vídeo principal */}
        <div className="mb-12">
          <div className="relative rounded-xl overflow-hidden shadow-xl">
            {/* Placeholder para vídeo - editável */}
            <div className="bg-gray-800 aspect-video flex items-center justify-center">
              <div className="text-center">
                <button className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-6 mb-4 transition-all">
                  <Play size={48} className="text-white" />
                </button>
                <p className="text-white text-xl">Clique para assistir ao vídeo</p>
              </div>
            </div>
            
            {/* Controles de vídeo */}
            <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-60 text-white p-4 flex items-center justify-between">
              <div className="flex items-center">
                <button className="mr-4">
                  <Play size={20} />
                </button>
                <div className="w-48 h-1 bg-gray-500 rounded-full overflow-hidden">
                  <div className="w-1/3 h-full bg-green-500"></div>
                </div>
                <span className="ml-2 text-sm">1:45 / 5:30</span>
              </div>
              <div className="flex items-center">
                <button className="flex items-center">
                  <Volume2 size={20} />
                  <div className="ml-2 w-16 h-1 bg-gray-500 rounded-full overflow-hidden">
                    <div className="w-2/3 h-full bg-white"></div>
                  </div>
                </button>
              </div>
            </div>
          </div>
          
          <h3 className="text-xl font-bold mt-4">Como escolher o melhor smartwatch para suas necessidades</h3>
          <p className="text-gray-600">Publicado em 15 de maio de 2025 • 5:30 minutos</p>
        </div>

        {/* Lista de vídeos relacionados */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((item) => (
            <div key={item} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                {/* Placeholder para thumbnail - editável */}
                <div className="bg-gray-800 aspect-video flex items-center justify-center">
                  <Play size={36} className="text-white opacity-80" />
                </div>
                <div className="absolute bottom-2 right-2 bg-black text-white text-xs px-2 py-1 rounded">
                  3:45
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="font-bold mb-2">Tutorial: Como configurar seu novo dispositivo</h3>
                <p className="text-gray-600 text-sm mb-2">
                  Aprenda a configurar e utilizar todos os recursos do seu novo produto D2Z.
                </p>
                <p className="text-gray-500 text-xs">Publicado em 10 de maio de 2025</p>
              </div>
            </div>
          ))}
        </div>
        
        {/* Botão para mais vídeos */}
        <div className="text-center mt-8">
          <a 
            href="#" 
            className="inline-block bg-red-600 text-white font-bold py-2 px-6 rounded-full hover:bg-red-700 transition"
          >
            Ver Mais Vídeos
          </a>
        </div>
      </div>
    </section>
  );
};

export default VideoSection;
