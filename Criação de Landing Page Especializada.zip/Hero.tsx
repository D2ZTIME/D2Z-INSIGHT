import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-r from-black to-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              D2Z-SHOP Blog
            </h1>
            <p className="text-xl mb-6">
              Descubra os Melhores Produtos para o seu Dia a Dia nos Artigos. Variedade, qualidade e praticidade em um só lugar.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#produtos"
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-full text-center transition duration-300"
              >
                Ver Produtos
              </a>
              <a
                href="#contato"
                className="bg-transparent hover:bg-white hover:text-black text-white font-bold py-3 px-6 rounded-full border-2 border-white text-center transition duration-300"
              >
                Fale Conosco
              </a>
            </div>
          </div>
          <div className="md:w-1/2">
            {/* Banner promocional baseado no conteúdo real */}
            <div className="bg-gray-800 rounded-lg p-8 text-center">
              <h2 className="text-3xl font-bold mb-2">Promoção Especial</h2>
              <p className="text-xl mb-4">Até 40% de desconto</p>
              <p className="text-lg mb-6">Smartwatches, Mochilas e muito mais!</p>
              <a
                href="#promocoes"
                className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded-full inline-block transition duration-300"
              >
                Aproveite Agora
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Indicador de rolagem */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M7 10L12 15L17 10"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
    </section>
  );
};

export default Hero;
