import React from 'react';
import { Menu, Search, ShoppingCart, User } from 'lucide-react';
import logo from '../../assets/images/LOGOD2Z.png';

const Header: React.FC = () => {
  return (
    <header className="bg-black text-white w-full">
      {/* Top bar */}
      <div className="container mx-auto px-4 py-2 flex justify-between items-center">
        <div className="flex items-center">
          <a href="#" className="text-green-500 hover:text-green-400 mr-4">
            Contato 17992518759
          </a>
        </div>
        <div className="flex items-center space-x-4">
          <a href="#" className="hover:text-gray-300 flex items-center">
            <User size={18} className="mr-1" />
            Entrar
          </a>
          <a href="#" className="hover:text-gray-300 flex items-center">
            <ShoppingCart size={18} className="mr-1" />
            Minhas Compras
          </a>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <a href="#" className="flex items-center">
            <img src={logo} alt="D2Z Shop" className="h-12 mr-2" />
            <span className="text-xl font-bold">D2Z-SHOP</span>
          </a>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <button className="text-white">
            <Menu size={24} />
          </button>
        </div>

        {/* Desktop navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#" className="hover:text-green-500">Novidades</a>
          <a href="#" className="hover:text-green-500">Produtos</a>
          <a href="#" className="hover:text-green-500">Promoções</a>
          <a href="#" className="hover:text-green-500">Blog</a>
          <a href="#" className="hover:text-green-500">Contato</a>
        </nav>

        {/* Search bar */}
        <div className="relative mt-4 md:mt-0 w-full md:w-64">
          <input
            type="text"
            placeholder="Buscar..."
            className="w-full px-4 py-2 rounded-full bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <button className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <Search size={18} className="text-gray-400" />
          </button>
        </div>
      </div>

      {/* Mobile navigation - hidden by default */}
      <div className="md:hidden hidden bg-gray-900 px-4 py-2">
        <div className="flex flex-col space-y-2">
          <a href="#" className="py-2 hover:text-green-500">Novidades</a>
          <a href="#" className="py-2 hover:text-green-500">Produtos</a>
          <a href="#" className="py-2 hover:text-green-500">Promoções</a>
          <a href="#" className="py-2 hover:text-green-500">Blog</a>
          <a href="#" className="py-2 hover:text-green-500">Contato</a>
        </div>
      </div>
    </header>
  );
};

export default Header;
