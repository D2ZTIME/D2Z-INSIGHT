import React from 'react';
import { Star } from 'lucide-react';

const Products: React.FC = () => {
  // Produtos reais do blog da D2Z Shop
  const products = [
    {
      id: 1,
      name: 'Smartwatch Xiaomi Mi Band 9 Active',
      description: 'A Revolução Tecnológica no Seu Pulso. Mais do que um simples relógio, este gadget representa um avanço significativo no universo dos wearables.',
      price: 294.90,
      originalPrice: 349.90,
      discount: 15,
      image: 'https://via.placeholder.com/300x300?text=Xiaomi+Mi+Band+9',
      tag: 'Promoção'
    },
    {
      id: 2,
      name: 'Mochila Expansível Executiva de Nylon',
      description: 'Praticidade e Elegância para Profissionais Modernos. Combinando design sofisticado com funcionalidades pensadas para o profissional moderno.',
      price: 280.00,
      originalPrice: 350.00,
      discount: 20,
      image: 'https://via.placeholder.com/300x300?text=Mochila+Executiva',
      tag: 'Promoção'
    },
    {
      id: 3,
      name: 'Mini Ventilador de Mesa com Umidificador',
      description: 'Conforto e Estilo para Qualquer Ambiente. Design compacto, funcionalidade silenciosa e umidificador integrado.',
      price: 49.90,
      originalPrice: 71.40,
      discount: 30,
      image: 'https://via.placeholder.com/300x300?text=Mini+Ventilador',
      tag: 'Promoção'
    },
    {
      id: 4,
      name: 'Maleta de Ferramentas Com Alça Grande',
      description: 'Organização e Praticidade para Profissionais e Amantes do "Faça Você Mesmo". A revolução na organização doméstica e profissional.',
      price: 138.90,
      originalPrice: 186.90,
      discount: 25,
      image: 'https://via.placeholder.com/300x300?text=Maleta+Ferramentas',
      tag: 'Promoção'
    }
  ];

  return (
    <section id="produtos" className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Produtos em Destaque</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Conheça nossa seleção de produtos com os melhores preços e qualidade garantida.
            Atualizamos nosso catálogo constantemente com as últimas novidades do mercado.
          </p>
        </div>

        {/* Filtros - editáveis */}
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          <button className="bg-black text-white px-6 py-2 rounded-full hover:bg-gray-800 transition">
            Todos
          </button>
          <button className="bg-white text-black px-6 py-2 rounded-full hover:bg-gray-200 transition border border-gray-300">
            Novidades
          </button>
          <button className="bg-white text-black px-6 py-2 rounded-full hover:bg-gray-200 transition border border-gray-300">
            Mais Vendidos
          </button>
          <button className="bg-white text-black px-6 py-2 rounded-full hover:bg-gray-200 transition border border-gray-300">
            Promoções
          </button>
        </div>

        {/* Grid de produtos */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105">
              {/* Tag de promoção */}
              {product.tag && (
                <div className="absolute top-0 right-0 bg-orange-500 text-white py-1 px-3 text-sm font-semibold">
                  {product.tag}
                </div>
              )}
              
              {/* Desconto */}
              {product.discount > 0 && (
                <div className="absolute top-0 left-0 bg-green-500 text-white rounded-br-lg py-1 px-3 text-sm font-semibold">
                  {product.discount}%
                </div>
              )}
              
              {/* Imagem do produto */}
              <div className="relative pt-[100%]">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="absolute top-0 left-0 w-full h-full object-cover"
                />
              </div>
              
              {/* Informações do produto */}
              <div className="p-4">
                <h3 className="font-bold text-lg mb-2 line-clamp-2">{product.name}</h3>
                <p className="text-gray-600 text-sm mb-3 line-clamp-3">{product.description}</p>
                
                <div className="flex items-center mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      size={16} 
                      className={i < 4 ? "text-yellow-500 fill-yellow-500" : "text-gray-300"} 
                    />
                  ))}
                  <span className="text-gray-600 text-sm ml-1">(4.0)</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    {product.originalPrice > product.price && (
                      <span className="text-gray-500 line-through text-sm mr-2">
                        R$ {product.originalPrice.toFixed(2)}
                      </span>
                    )}
                    <span className="text-black font-bold">
                      R$ {product.price.toFixed(2)}
                    </span>
                  </div>
                  <button className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded-full text-sm transition">
                    Ver Detalhes
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Botão para ver mais produtos */}
        <div className="text-center mt-12">
          <a 
            href="#" 
            className="inline-block bg-black text-white font-bold py-3 px-8 rounded-full hover:bg-gray-800 transition"
          >
            Ver Todos os Produtos
          </a>
        </div>
      </div>
    </section>
  );
};

export default Products;
